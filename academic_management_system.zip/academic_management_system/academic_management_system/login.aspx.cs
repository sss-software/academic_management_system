﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
namespace academic_management_system
{
    public partial class login : System.Web.UI.Page
    {
        SqlConnection conn = new SqlConnection(@"Data Source=RAIBAGKARS-PC;Initial Catalog=academic_management_systemdb;Integrated Security=True");
        SqlCommand cmd;
        SqlCommand query1=new SqlCommand();
        SqlDataReader rdr;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string strusername, strpassword,euser,epass;
            int tid;
            strusername = TextBox1.Text;
            strpassword = TextBox2.Text;
            tid = Convert.ToInt32(TextBox3.Text);
            //query1.CommandText = "select class_teacher from cse_load_distribution_table where (faculty_id=" + tid + ")";
            //query1.Connection = conn;
            /*If teacher is Class Teacher then display tasks.aspx page else display attendance_select_class.aspx*/
            //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
            conn.Open();
            string que = "select username,password from cse_faculty_details where (faculty_id=" + tid + ")";
            cmd = new SqlCommand(que, conn);
            
            rdr = cmd.ExecuteReader();
            rdr.Read();
            euser = rdr[0].ToString();
            epass = rdr[1].ToString();
                               /*"admin"*/             /*"admin"*/
            if (strusername == euser && strpassword == epass )
            {
                Session["username"] = strusername;
                Session["password"] = strpassword;
                Response.Redirect("~/attendance_select_class.aspx");
                // Response.Redirect("~/tasks.aspx");

            }
            rdr.Close();
            conn.Close();
        }
    }
}