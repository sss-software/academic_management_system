﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Text;
using System.Configuration;

namespace academic_management_system
{
    public partial class addattendance : System.Web.UI.Page

    {
        string startdate;//---------------------------------------------------------------------
        string enddate;//-----------------------------------------------------------------------
        SqlCommand cmd1=new SqlCommand();
        SqlCommand cmd2 = new SqlCommand();
        SqlCommand cmd3=new SqlCommand();
        SqlCommand cmd4 = new SqlCommand();
        SqlCommand cmd5=new SqlCommand();

        SqlDataAdapter da1 = new SqlDataAdapter();
        SqlDataAdapter da2 = new SqlDataAdapter();
        SqlDataAdapter da3 = new SqlDataAdapter();
        SqlDataAdapter da4 = new SqlDataAdapter();
        SqlDataAdapter da5 = new SqlDataAdapter();




        DataSet ds = new DataSet();
        DataSet sgridview = new DataSet();

        string q1, q2, q3, q4, q5;


        SqlConnection con;
        SqlCommand cmd;
        DataTable dt1 = new DataTable();
        Int32 srno = 0;
        int totalPresent = 0;
        int initialno = 0;    
        string sname =null ;      
        string sclass = null;     
        string sdiv = null;      
        string que = null;
        string sdate = null;
        string attsub=null;

        SqlDataAdapter adapter1 = new SqlDataAdapter();
        DataSet ds1 = new DataSet();
        SqlCommand query1 = new SqlCommand();
        SqlCommand query2 = new SqlCommand();

        protected void Page_Load(object sender, EventArgs e)
        {
            Label3.Visible = false;
            Label4.Visible = false;
            DropDownList1.Visible = false;
            DropDownList2.Visible = false;
            DropDownList3.Visible = false;
            DropDownList4.Visible = false;
            DropDownList5.Visible = false;
            DropDownList6.Visible = false;
            Button1.Visible = false;


            con = new SqlConnection(@"Data Source=RAIBAGKARS-PC;Initial Catalog=academic_management_systemdb;Integrated Security=True");
            if (!IsPostBack)
            {
                sclass = Session["attclass"].ToString();
                sdiv = Session["attDiv"].ToString();
                query1.CommandText = "select rollno,fname,class,div from addstudentdata_db where (class =  '" + sclass + "') and  (div = '" + sdiv + "')";//<<<<<<<<<<<<<<<<<<<
                
                query2.Connection = con;
                attsub = Convert.ToString(Session["attsubject"]);
                Lbldate.Text = Convert.ToString(Session["attdate"]);
                Lblclass.Text = Convert.ToString(Session["attclass"]);
                Lbldiv.Text = Convert.ToString(Session["attDiv"]);
                
                Lblsubject.Text = Convert.ToString(Session["attsubject"]);
                
                con.Open();
                foreach (DataRow dr1 in dt1.Rows)
                {
                    srno = Convert.ToInt32(dr1["rollno"]);
                    sname = dr1["fname"].ToString();
                    sclass = dr1["class"].ToString();
                    sdiv = dr1["div"].ToString();
                    sdate = Session["attdate"].ToString();

                    if (initialno == 0)
                    {
                        initialno = srno;
                    }
                    
                }
                con.Close();
            }
            if(IsPostBack)
            {
                sclass = Session["attclass"].ToString();
                sdiv = Session["attDiv"].ToString();
                query1.CommandText = "select rollno,fname,class,div from addstudentdata_db where (class =  '" + sclass + "') and  (div = '" + sdiv + "')";//<<<<<<<<<<<<<<<<<<<
                attsub = Convert.ToString(Session["attsubject"]);
                query2.Connection = con;
                Lbldate.Text = Convert.ToString(Session["attdate"]);
                Lblclass.Text = Convert.ToString(Session["attclass"]);
                Lbldiv.Text = Convert.ToString(Session["attDiv"]);
                Lblsubject.Text = Convert.ToString(Session["attsubject"]);
                
                if (initialno == 0)
                {
                    initialno = srno;
                }
                            }
            
        }
        protected void AddAttendanceSave_Click(object sender, EventArgs e)
        {

            con.Open();
            adapter1.SelectCommand = new SqlCommand(query1.CommandText, con);
            adapter1.Fill(ds1);
            
            dt1 = ds1.Tables[0];


            foreach (DataRow dr1 in dt1.Rows)
            {
                srno = Convert.ToInt32(dr1["rollno"]);
                sname = dr1["fname"].ToString();
                sclass = dr1["class"].ToString();
                sdiv = dr1["div"].ToString();
                sdate = Session["attdate"].ToString();

                if (initialno == 0)
                {
                    initialno = srno;
                }
                query2.CommandText = "insert into cse_attendancetable (cse_attendance_total_lectures,cse_attendance_subject,cse_attendance_rollno,cse_attendance_studentname,cse_attendance_class,cse_attendance_classdiv,cse_attendance_date) values (1,'"+attsub+ "',"+ srno + ",'" + sname + "','" + sclass + "','" + sdiv + "',CONVERT(DATETIME,'" + sdate + "'));";
                query2.ExecuteNonQuery();
            }

            foreach (GridViewRow row in GridView1.Rows)
            {
                if (row.RowType == DataControlRowType.DataRow) //avoid header/footer rows.
                {

                    CheckBox chk = (CheckBox)row.FindControl("CheckBox1");

                    if (chk.Checked == true)
                    {
                        int ispresent = 1;
                        que = "UPDATE cse_attendancetable SET cse_attendance_present=" + ispresent + " WHERE (cse_attendance_date= CONVERT(DATETIME,'" + sdate + "') )and (cse_attendance_rollno=" + initialno + ");";
                        totalPresent++;
                        initialno++;
                    }
                    else
                    {
                        int ispresent = 0;
                        que = "UPDATE cse_attendancetable SET cse_attendance_rollno=" + initialno + " WHERE (cse_attendance_date=CONVERT(DATETIME,'" + sdate + "') )and (cse_attendance_rollno=" + initialno + ");";
                        initialno++;
        
                    }
                    cmd = new SqlCommand(que, con);
                    cmd.ExecuteNonQuery();
                 }
                
            }
            con.Close();
        }

        protected void Gendefault_Click(object sender, EventArgs e)
        {
            Label3.Visible = true;
            Label4.Visible = true;
            DropDownList1.Visible = true;
            DropDownList2.Visible = true;
            DropDownList3.Visible = true;
            DropDownList4.Visible = true;
            DropDownList5.Visible = true;
            DropDownList6.Visible = true;
            Button1.Visible = true;


        }




        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string d;
            startdate = DropDownList1.SelectedValue;
            //TextBox1.Text = startdate.ToString();
        }

        protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
        {
            string m;
            m = DropDownList2.SelectedValue;
            startdate = "" + startdate + "-" + "" + m + "";

        }

        protected void DropDownList3_SelectedIndexChanged(object sender, EventArgs e)
        {
            string y;
            y = DropDownList3.SelectedValue;
            startdate = "" + startdate + "-" + "" + y + "";
            startdate = startdate.ToString();
            Label3.Text = startdate.ToString();
        }

        protected void DropDownList4_SelectedIndexChanged(object sender, EventArgs e)
        {
            string d;
            enddate = DropDownList4.SelectedValue;

        }

        protected void DropDownList5_SelectedIndexChanged(object sender, EventArgs e)
        {
            string m;
            m = DropDownList5.SelectedValue;
            enddate = "" + enddate + "-" + "" + m + "";

        }

        protected void DropDownList6_SelectedIndexChanged(object sender, EventArgs e)
        {
            string y;
            y = DropDownList6.SelectedValue;
            enddate = "" + enddate + "-" + "" + y + "";
            enddate = enddate.ToString();

        }



        protected void Button1_Click(object sender, EventArgs e)
        {

            cmd1.CommandText = "SELECT cse_attendance_rollno, (COUNT(cse_attendance_present)*100)/COUNT(cse_attendance_total_lectures)as OS FROM cse_attendancetable where cse_attendance_class='" + sclass + "' AND cse_attendance_classdiv='" + sdiv + "'AND cse_attendance_subject='OS' AND cse_attendance_date between CONVERT(DATETIME,'" + startdate + "') and CONVERT(DATETIME,'" + enddate + "') group by cse_attendance_rollno ";
            cmd2.CommandText = "SELECT cse_attendance_rollno, (COUNT(cse_attendance_present)*100)/COUNT(cse_attendance_total_lectures)as SE FROM cse_attendancetable where cse_attendance_class='" + sclass + "' AND cse_attendance_classdiv='" + sdiv + "'AND cse_attendance_subject='SE' AND cse_attendance_date between CONVERT(DATETIME,'" + startdate + "') and CONVERT(DATETIME,'" + enddate + "') group by cse_attendance_rollno ";
            cmd3.CommandText = "SELECT cse_attendance_rollno, (COUNT(cse_attendance_present)*100)/COUNT(cse_attendance_total_lectures)as DIP FROM cse_attendancetable where cse_attendance_class='" + sclass + "' AND cse_attendance_classdiv='" + sdiv + "'AND cse_attendance_subject='DIP' AND cse_attendance_date between CONVERT(DATETIME,'" + startdate + "') and CONVERT(DATETIME,'" + enddate + "') group by cse_attendance_rollno ";
            cmd4.CommandText = "SELECT cse_attendance_rollno, (COUNT(cse_attendance_present)*100)/COUNT(cse_attendance_total_lectures)as PIJ FROM cse_attendancetable where cse_attendance_class='" + sclass + "' AND cse_attendance_classdiv='" + sdiv + "'AND cse_attendance_subject='PIJ' AND cse_attendance_date between CONVERT(DATETIME,'" + startdate + "') and CONVERT(DATETIME,'" + enddate + "') group by cse_attendance_rollno ";
            cmd5.CommandText = "SELECT cse_attendance_rollno, (COUNT(cse_attendance_present)*100)/COUNT(cse_attendance_total_lectures)as DBMS FROM cse_attendancetable where cse_attendance_class='" + sclass + "' AND cse_attendance_classdiv='" + sdiv + "'AND cse_attendance_subject='DBMS' AND cse_attendance_date between CONVERT(DATETIME,'" + startdate + "') and CONVERT(DATETIME,'" + enddate + "') group by cse_attendance_rollno ";
            cmd1.Connection = con;
            cmd2.Connection = con;
            cmd3.Connection = con;
            cmd4.Connection = con;
            cmd5.Connection = con;


            con.Open();
            da1.SelectCommand = new SqlCommand(cmd1.CommandText, con);
            da1.Fill(ds);

            da2.SelectCommand = new SqlCommand(cmd2.CommandText, con);
            da2.Fill(ds);

            da3.SelectCommand = new SqlCommand(cmd3.CommandText, con);
            da3.Fill(ds);


            da4.SelectCommand = new SqlCommand(cmd4.CommandText, con);
            da4.Fill(ds);

            da5.SelectCommand = new SqlCommand(cmd5.CommandText, con);
            da5.Fill(ds);


            sgridview = ds;

            string val;
            DataTable t1 = sgridview.Tables[0];
            foreach (DataRow r1 in t1.Rows)
            {
                val = r1["cse_attendance_rollno"].ToString();
                val = r1["OS"].ToString();
            }
            Session["sgridview"] = ds;
            con.Close();
            
            Response.Redirect("~/attendancedefaulter.aspx");

        }
             

        
    }
}