﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Text;
using System.Configuration;

namespace academic_management_system
{
    public partial class attendancedefaulter : System.Web.UI.Page
    {
        //DataSet sgridview;
        //DataSet sgridview = new DataSet();
        protected void Page_Load(object sender, EventArgs e)
        {

            DataSet gvDS = (DataSet)Session["sgridview"];
            GridView1.DataSource = gvDS;
           GridView1.DataBind();
           //gvDS.Clear();//---------------------------------------------------------
            //Session.Clear();
        }

        protected void GridView1_SelectedIndexChanged(object sender, GridViewPageEventArgs e)
        {
           
        }

           
        
    }
}