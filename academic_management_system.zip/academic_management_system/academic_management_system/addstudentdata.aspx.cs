﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
namespace academic_management_system
{
    public partial class addstudentdata : System.Web.UI.Page
    {
        SqlConnection con;
        SqlCommand cmd;
        SqlDataReader rdr;
      
            
        protected void Page_Load(object sender, EventArgs e)
        {
            con = new SqlConnection(@"Data Source=RAIBAGKARS-PC;Initial Catalog=academic_management_systemdb;Integrated Security=True");
            if (!IsPostBack) // this is to be in the function of pageload only
            {              
            }
        }

        
        protected void Btnsave_Click(object sender, EventArgs e)
        {
            Int32 rolno = Convert.ToInt32(Txtrno.Text);
            Int64 prn = Convert.ToInt64(Txtprn.Text);
            String atype = DDLaddtype.SelectedValue;
            Int32 ayear = Convert.ToInt32(Txtaddyr.Text);
            String fname = Txtfname.Text;
            String mname = Txtmname.Text;
            String lname = Txtlname.Text;
            String bdate = Txtdob.Text;
            String catagory = DDLcategory.SelectedValue;
            String cast = Txtcaste.Text;
            String gender = DDLgender.SelectedValue;
            Int64 mno = Convert.ToInt64(Txtmobno.Text);
            String email = Txtemail.Text;
            Int64 lno = Convert.ToInt64(Txtlandno.Text);
            String mothername = Txtmothername.Text;
            String poccupation = Txtparocc.Text;
            String padd = Txtperadd.Text;
            String tadd = Txttempadd.Text;
            Int64 ano = Convert.ToInt64(Txtaadharno.Text);
            Int64 panno = Convert.ToInt64(Txtpanno.Text);
            Int32 apfee = Convert.ToInt32(Txtadmpf.Text);
            String fidate = Txt1instdate.Text;
            String sidate = Txt2instdate.Text;
            String clas = DDLclass.SelectedValue;
            String branch = DDLbranch.SelectedValue;
            String divison =  DDLdiv.SelectedValue;
            Int32 femarks = Convert.ToInt32(Txtfyrmrk.Text);
            Int32 semarks = Convert.ToInt32(Txtsyrmrk.Text);
            Int32 temarks = Convert.ToInt32(Txttyrmrk.Text);
            con.Open();
            String que = "insert into addstudentdata_db (rollno,prn,admissiontype,admissionyear,fname,mname,lname,dob,category,caste,gender,mobile,email,lnumber,mothername,parentocc,padd,tadd,aadharno,pan,apfee,finstallment,sinstallment,class,branch,div,femarks,semarks,temarks) values (" + rolno + "," + prn + ",'" + atype + "'," + ayear + ",'" + fname + "','" + mname + "','" + lname + "','" + bdate + "','" + catagory + "','" + cast + "','" + gender + "'," + mno + ",'" + email + "'," + lno + ",'" + mothername + "','" + poccupation + "','" + padd + "','" + tadd + "'," + ano + "," + panno + "," + apfee + ",'" + fidate + "','" + sidate + "','" + clas + "','" + branch + "','" + divison + "'," + femarks + "," + semarks + "," + temarks + ")";
            cmd = new SqlCommand(que, con);

            cmd.ExecuteNonQuery();
            con.Close();
        }

        protected void Btnupdate_Click(object sender, EventArgs e)
        {
            Int32 rolno = Convert.ToInt32(Txtrno.Text);
            Int64 prn = Convert.ToInt64(Txtprn.Text);
            String atype = DDLaddtype.SelectedValue;
            Int32 ayear = Convert.ToInt32(Txtaddyr.Text);
            String fname = Txtfname.Text;
            String mname = Txtmname.Text;
            String lname = Txtlname.Text;
            String bdate = Txtdob.Text;
            String catagory = DDLcategory.SelectedValue;
            String cast = Txtcaste.Text;
            String gender = DDLgender.SelectedValue;
            Int64 mno = Convert.ToInt64(Txtmobno.Text);
            String email = Txtemail.Text;
            Int64 lno = Convert.ToInt64(Txtlandno.Text);
            String mothername = Txtmothername.Text;
            String poccupation = Txtparocc.Text;
            String padd = Txtperadd.Text;
            String tadd = Txttempadd.Text;
            Int64 ano = Convert.ToInt64(Txtaadharno.Text);
            Int64 panno = Convert.ToInt64(Txtpanno.Text);
            Int32 apfee = Convert.ToInt32(Txtadmpf.Text);
            String fidate = Txt1instdate.Text;
            String sidate = Txt2instdate.Text;
            String clas = DDLclass.SelectedValue;
            String branch = DDLbranch.SelectedValue;
            String divison = DDLdiv.SelectedValue;
            Int32 femarks = Convert.ToInt32(Txtfyrmrk.Text);
            Int32 semarks = Convert.ToInt32(Txtsyrmrk.Text);
            Int32 temarks = Convert.ToInt32(Txttyrmrk.Text);
            con.Open();
            String que = "update addstudentdata_db set prn=" + prn + ", admissiontype='" + atype + "',admissionyear=" + ayear + ",fname='" + fname + "',mname='" + mname + "',lname='" + lname + "',dob='" + bdate + "',catagory='" + catagory + "',caste='" + cast + "',gender='" + gender + "',mobile=" + mno + ",email='" + email + "',lnumber=" + lno + ",mothername='" + mothername + "',parentocc='" + poccupation + "',padd='" + padd + "',tadd='" + tadd + "',aadharno=" + ano + ",pan=" + panno + ",apfee=" + apfee + ",finstallment='" + fidate + "',sinstallment='" + sidate + "',class='" + clas + "',div='" + divison + "',branch='" + branch + "',femarks=" + femarks + ",semarks=" + semarks + ",temarks=" + temarks + " where rollno= " + rolno + "";
            cmd = new SqlCommand(que, con);
            cmd.ExecuteNonQuery();

            con.Close();
        }

        protected void Btnshow_Click(object sender, EventArgs e)
        {
            Int32 rolno = Convert.ToInt32(Txtrno.Text);

            con.Open();
            String que = "select * from addstudentdata_db where rollno=" + rolno + "";
            cmd = new SqlCommand(que, con);
            rdr = cmd.ExecuteReader();

            rdr.Read();
            Txtrno.Text = rdr[1].ToString();
            Txtprn.Text = rdr[2].ToString();
            Txtaddyr.Text = rdr[4].ToString();
            Txtfname.Text = rdr[5].ToString();
            Txtmname.Text = rdr[6].ToString();
            Txtlname.Text = rdr[7].ToString();
            Txtdob.Text = rdr[8].ToString();
            Txtcaste.Text = rdr[10].ToString();
            Txtmobno.Text = rdr[12].ToString();
            Txtemail.Text = rdr[13].ToString();
            Txtlandno.Text = rdr[14].ToString();
            Txtmothername.Text = rdr[15].ToString();
            Txtparocc.Text = rdr[16].ToString();
            Txtperadd.Text = rdr[17].ToString();
            Txttempadd.Text = rdr[18].ToString();
            Txtaadharno.Text = rdr[19].ToString();
            Txtpanno.Text = rdr[20].ToString();
            Txtadmpf.Text = rdr[21].ToString();
            Txt1instdate.Text = rdr[22].ToString();
            Txt2instdate.Text = rdr[23].ToString();
            Txtfyrmrk.Text = rdr[27].ToString();
            Txtsyrmrk.Text = rdr[28].ToString();
            Txttyrmrk.Text = rdr[29].ToString();
            rdr.Close();
            con.Close();
        }

        protected void Btndelete_Click(object sender, EventArgs e)
        {
            Int32 rolno = Convert.ToInt32(Txtrno.Text);
            con.Open();
            String que = "delete from addstudentdata_db where rollno=" + rolno + " ";
            cmd = new SqlCommand(que, con);

            cmd.ExecuteNonQuery();
            con.Close();

        }

        protected void Txtrno_TextChanged(object sender, EventArgs e)
        {

        }

               
       
    }
}
