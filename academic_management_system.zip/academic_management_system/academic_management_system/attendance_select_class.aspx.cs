﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

namespace academic_management_system
{
    public partial class attendance_select_class : System.Web.UI.Page
    {

        DataTable dt2 = new DataTable();
        DataTable dt3 = new DataTable();
        DataTable dt4 = new DataTable();
        DataTable dt5 = new DataTable();
        DataTable dt1 = new DataTable();
       
        string struser1;
        string strpassword1;
        public string attdate;
        public string attclass;
        public Int32 faculty_id;
        public string attDiv;
        public string attsubject;

        SqlDataAdapter adapter1 = new SqlDataAdapter();
        DataSet ds1 = new DataSet();
        SqlDataAdapter adapter2 = new SqlDataAdapter();
        DataSet ds2 = new DataSet();
        SqlDataAdapter adapter3 = new SqlDataAdapter();
        DataSet ds3 = new DataSet();
        SqlDataAdapter adapter4 = new SqlDataAdapter();
        DataSet ds4 = new DataSet();
        SqlDataAdapter adapter5 = new SqlDataAdapter();
        DataSet ds5 = new DataSet();
        SqlCommand query1 = new SqlCommand();
        SqlCommand query2 = new SqlCommand();
        SqlCommand query3 = new SqlCommand();
        SqlCommand query4 = new SqlCommand();
        SqlCommand query5 = new SqlCommand();
        
        SqlCommand cmd;
        SqlDataReader rdr;
        SqlConnection conn = new SqlConnection(@"Data Source=RAIBAGKARS-PC;Initial Catalog=academic_management_systemdb;Integrated Security=True");
        protected void Page_Load(object sender, EventArgs e)
        {
            
            struser1 = Convert.ToString(Session["username"]);
            strpassword1 = Convert.ToString(Session["password"]);
            
            query1.CommandText = "select faculty_id from cse_faculty_details where username='" + struser1 + "' and password='" + strpassword1 + "';";
            query1.Connection = conn;

            conn.Open();
            adapter1.SelectCommand = new SqlCommand(query1.CommandText, conn);
            adapter1.Fill(ds1);
            dt1 = ds1.Tables[0];
            foreach (DataRow dr1 in dt1.Rows)
            {
                faculty_id = Convert.ToInt32(dr1["faculty_id"].ToString());//<<<<<------ERROR IS HERE-----
            }
            conn.Close();
            if (!IsPostBack)
            {
                
                query2.CommandText = "select classtype from cse_load_distribution_table where faculty_id=" + faculty_id + ";";
                query2.Connection = conn;

                conn.Open();
                adapter2.SelectCommand = new SqlCommand(query2.CommandText, conn);
                adapter2.Fill(ds2);
                conn.Close();

                dt2 = ds2.Tables[0];

                foreach (DataRow dr1 in dt2.Rows)
                {
                    
                    //-----------IF CLASS IS SE
                    if (dr1["classtype"].ToString() == "SE")
                    {
                        Class_name.Items[0].Enabled = true;
                        
                    }
                    if (dr1["classtype"].ToString() == "TE")
                    {
                        Class_name.Items[1].Enabled = true;
                        
                    }

                    if (dr1["classtype"].ToString() == "BE")
                    {
                        Class_name.Items[2].Enabled = true;
                        
                    }
                }
                
                }
        }


        

        protected void Class_name_SelectedIndexChanged(object sender, EventArgs e)
        {
            //--------DIVISION NO-----------
            query3.CommandText = "select divisionno from cse_load_distribution_table where faculty_id=" + faculty_id + "and classtype='SE';";
            query3.Connection = conn;

            query4.CommandText = "select divisionno from cse_load_distribution_table where faculty_id=" + faculty_id + "and classtype='TE';";
            query4.Connection = conn;


            query5.CommandText = "select divisionno from cse_load_distribution_table where faculty_id=" + faculty_id + "and classtype='BE';";
            query5.Connection = conn;


            conn.Open();


            adapter3.SelectCommand = new SqlCommand(query3.CommandText, conn);
            adapter3.Fill(ds3);

            adapter4.SelectCommand = new SqlCommand(query4.CommandText, conn);
            adapter4.Fill(ds4);

            adapter5.SelectCommand = new SqlCommand(query5.CommandText, conn);
            adapter5.Fill(ds5);


            conn.Close();
            dt3 = ds3.Tables[0];
            dt4 = ds4.Tables[0];
            dt5 = ds5.Tables[0];

            if (Class_name.SelectedIndex == 0)
            {
                
                foreach (DataRow dr2 in dt3.Rows)
                {
                    if (dr2["divisionno"].ToString() == "A")
                    {
                        division.Items[0].Enabled = true;
                        if (dt3.Rows.Count > 1)
                        {
                            division.Items[0].Selected = true;
                            division.Items[1].Selected = true;
                        }
                        else
                        {
                            division.Items[0].Selected = false;
                        }
                    }
                    if (dr2["divisionno"].ToString() == "B")
                    {
                        division.Items[1].Enabled = true;
                        if (dt3.Rows.Count > 1)
                        {
                            division.Items[0].Selected = true;
                            division.Items[1].Selected = true;
                        }
                        else
                        {
                            division.Items[0].Selected = false;
                        }
                    }

                }
            }
            if (Class_name.SelectedIndex == 1)
            {
                
                foreach (DataRow dr2 in dt4.Rows)
                {
                    if (dr2["divisionno"].ToString() == "A")
                    {
                        division.Items[0].Enabled = true;
                        if (dt4.Rows.Count > 1)
                        {
                            division.Items[0].Selected = true;
                            division.Items[1].Selected = true;
                        }
                        else
                        {
                            division.Items[0].Selected = false;
                        }
                    }
                    if (dr2["divisionno"].ToString() == "B")
                    {
                        division.Items[1].Enabled = true;
                        if (dt4.Rows.Count > 1)
                        {
                            division.Items[0].Selected = true;
                            division.Items[1].Selected = true;
                        }
                        else
                        {
                            division.Items[0].Selected = false;
                        }
                    }

                }
            }
            if (Class_name.SelectedIndex == 2)
            {
                
                    foreach (DataRow dr2 in dt5.Rows)
                {
                    if (dr2["divisionno"].ToString() == "A")
                    {
                        division.Items[0].Enabled = true;
                        if (dt5.Rows.Count > 1)
                        {
                            division.Items[0].Selected = true;
                            division.Items[1].Selected = true;
                        }
                        else
                        {
                            division.Items[0].Selected = false;
                        }
                    }
                    if (dr2["divisionno"].ToString() == "B")
                    {
                        division.Items[1].Enabled = true;
                        if (dt5.Rows.Count > 1)
                        {
                            division.Items[0].Selected = true;
                            division.Items[1].Selected = true;
                        }
                        else
                        {
                            division.Items[0].Selected = false;
                        }
                    }

                }
            }
        }

     
        protected void Submit_Click(object sender, EventArgs e)
        {
            attclass = Class_name.SelectedValue.ToString();
            attDiv = division.SelectedValue.ToString();
         //   attdate = TextBox1.Text;

            Session["attclass"] = Class_name.SelectedValue.ToString();
            Session["attDiv"] = division.SelectedValue.ToString();
            Session["attdate"] = attdate/*TextBox1.Text*/;

            conn.Open();
            string que = "select th_load from cse_load_distribution_table where (faculty_id=" + faculty_id + ") and (classtype='" + attclass + "') and (divisionno='" + attDiv + "')";
            cmd = new SqlCommand(que, conn);
            
            rdr = cmd.ExecuteReader();
            rdr.Read();
            attsubject = rdr[0].ToString();
            rdr.Close();
            
            conn.Close();
            Session["attsubject"] = attsubject;
            Response.Redirect("~/addattendance.aspx");
            
        }

        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string d;
            attdate = DropDownList1.SelectedValue;
            //TextBox1.Text = attdate.ToString();
        }

        protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
        {
            string m;
            m = DropDownList2.SelectedValue;
            attdate = "" + attdate + "-" + "" + m + "";
            //TextBox1.Text = attdate.ToString();
        }

        protected void DropDownList3_SelectedIndexChanged(object sender, EventArgs e)
        {
            string y;
            y = DropDownList3.SelectedValue;
            attdate = "" + attdate + "-" + "" + y + "";
            attdate = attdate.ToString();
            //TextBox1.Text = attdate.ToString();
        }   
     }
}